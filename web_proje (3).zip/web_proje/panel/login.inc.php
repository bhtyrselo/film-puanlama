<?php  
session_start();
include("../db_connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mail = $_POST['email'];
    $sifre = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, mail, sifre FROM kullanicilar WHERE mail = ?");
    $stmt->bind_param("s", $mail);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id,  $db_mail, $db_password);
        $stmt->fetch();
        
        if ($sifre == $db_password) {
            $_SESSION['user_id'] = $id;
            $_SESSION['username'] = $db_username;
            header("Location: ./index.php");
            exit;
        } else {
            $error = "Hatalı şifre.";
            header("Location: ./login.php");
            exit;
        }
    } else {
        $error = "Kullanıcı adı bulunamadı.";
        header("Location: ./login.php");
            exit;
    }
    
    $stmt->close();
    $conn->close();
}




?>
