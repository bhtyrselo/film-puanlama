// JavaScript kodu
$('i.fa-star').click(function(){
    var rate = $(this).data('value');
    console.log(rate); // Bu satır, tıklanan yıldıza karşılık gelen puanı konsola yazdıracaktır.
    // Geri kalan kodlar buraya gelecek
});
